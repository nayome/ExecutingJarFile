//
//  MailAttachmentMain.m
//  MailAttachment
//
//  Created by DATAPPS on 11/30/17.
//  Copyright © 2017 Tester. All rights reserved.
//

#import "MailAttachmentMain.h"

@interface MailAttachmentMain (SMPNoImplementation)
+ (void)registerBundle;
@end

@implementation MailAttachmentMain

+ (void)initialize {
    Class mvMailBundleClass = NSClassFromString(@"MVMailBundle");
    // If this class is not available that means Mail.app
    // doesn't allow bundles anymore. Fingers crossed that this never happens!
    if (!mvMailBundleClass) {
        NSLog(@"Mail.app doesn't support bundles anymore, So deadlock !");
        
        return;
    }
    
    // Registering plugin in Mail.app
    [mvMailBundleClass registerBundle];
    
    NSLog(@"Mail Attachment plugin successfully Loaded");
}
@end
